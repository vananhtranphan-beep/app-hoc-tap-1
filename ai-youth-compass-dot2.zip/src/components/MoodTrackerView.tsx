import React, { useState, useEffect, useRef, useMemo } from "react";
import { MathMarkdown } from "./MathMarkdown";
import {
  Smile,
  Heart,
  Sparkles,
  Play,
  Pause,
  RotateCcw,
  ShieldCheck,
  Clock,
  Calendar,
  Trash2,
  Zap,
  MessageCircle,
  BarChart3,
  Flame,
  Send,
  Bot,
  Droplets,
  X
} from "lucide-react";
import { MoodLog, EmotionTreeState } from "../types";

export const MOOD_OPTIONS = [
  { id: "vui", label: "Vui Vẻ", emoji: "😃", bg: "bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100", accent: "#059669", score: 0 },
  { id: "haohung", label: "Hào Hứng", emoji: "🥳", bg: "bg-teal-50 text-teal-700 border-teal-200 hover:bg-teal-100", accent: "#0d9488", score: 0 },
  { id: "binhthuong", label: "Bình Thường", emoji: "😐", bg: "bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100", accent: "#2563eb", score: 1 },
  { id: "buon", label: "Buồn Chán", emoji: "😭", bg: "bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200", accent: "#475569", score: 3 },
  { id: "apluc", label: "Áp Lực Thi Cử", emoji: "😫", bg: "bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100", accent: "#d97706", score: 4 },
  { id: "lolang", label: "Lo Lắng Bài Vở", emoji: "😟", bg: "bg-orange-50 text-orange-700 border-orange-200 hover:bg-orange-100", accent: "#ea580c", score: 4 },
  { id: "buctuc", label: "Bực Tức", emoji: "😡", bg: "bg-rose-50 text-rose-700 border-rose-200 hover:bg-rose-100", accent: "#e11d48", score: 5 },
  { id: "metmoi", label: "Mệt Mỏi", emoji: "😴", bg: "bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100", accent: "#9333ea", score: 5 },
];

function getPast30Days(): { dateStr: string; displayDate: string; dayNum: number }[] {
  const days = [];
  const today = new Date();
  for (let i = 29; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(today.getDate() - i);
    days.push({
      dateStr: d.toLocaleDateString("vi-VN"),
      displayDate: `${d.getDate()}/${d.getMonth() + 1}`,
      dayNum: d.getDate(),
    });
  }
  return days;
}

const RealisticEmotionTree: React.FC<{ health: number; isWatering: boolean }> = ({ health, isWatering }) => {
  // Ngưỡng trạng thái GIỮ NGUYÊN như cũ: >=80 xum xuê, >=50 khỏe mạnh, <30 rũ lá
  const isLush = health >= 80;
  const isHealthy = health >= 50;
  const isWilted = health < 30;

  // Màu bầu trời đổi theo sức khỏe cây (chỉ trang trí)
  const sky = isLush
    ? ["#38bdf8", "#0f766e", "#022c22"]
    : isHealthy
    ? ["#0e7490", "#134e4a", "#022c22"]
    : ["#3730a3", "#1e1b4b", "#0f172a"];

  const sparkle = "M0,-6 L1.6,-1.6 L6,0 L1.6,1.6 L0,6 L-1.6,1.6 L-6,0 L-1.6,-1.6 Z";

  return (
    <div className="relative w-full max-w-md mx-auto h-72 sm:h-80 select-none overflow-hidden rounded-3xl border border-emerald-400/30 shadow-[0_0_40px_-10px_rgba(16,185,129,0.45)]">
      {isWatering && (
        <div className="absolute top-2 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center animate-bounce duration-500">
          <div className="flex items-center gap-1 bg-cyan-500 text-white px-3 py-1 rounded-full text-xs font-bold shadow-lg border border-cyan-200">
            <Droplets className="w-4 h-4 animate-pulse" />
            <span>Đang Tưới Cây Nước Mát...</span>
          </div>
        </div>
      )}

      <svg viewBox="0 0 300 240" className="absolute inset-0 w-full h-full" preserveAspectRatio="xMidYMid slice">
        <defs>
          <linearGradient id="et-sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={sky[0]} stopOpacity="0.85" />
            <stop offset="55%" stopColor={sky[1]} />
            <stop offset="100%" stopColor={sky[2]} />
          </linearGradient>
          <radialGradient id="et-sunGlow">
            <stop offset="0%" stopColor="#fde68a" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#fde68a" stopOpacity="0" />
          </radialGradient>
          <radialGradient id="et-aura">
            <stop offset="0%" stopColor="#6ee7b7" stopOpacity="0.55" />
            <stop offset="100%" stopColor="#6ee7b7" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="soilGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#451a03" />
            <stop offset="100%" stopColor="#1c0d02" />
          </linearGradient>
          <linearGradient id="trunkGrad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#582f0e" />
            <stop offset="50%" stopColor="#8b5a2b" />
            <stop offset="100%" stopColor="#3a1e05" />
          </linearGradient>
          <linearGradient id="lushFoliage" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#6ee7b7" />
            <stop offset="45%" stopColor="#10b981" />
            <stop offset="100%" stopColor="#065f46" />
          </linearGradient>
          <linearGradient id="healthyFoliage" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#86efac" />
            <stop offset="100%" stopColor="#15803d" />
          </linearGradient>
          <linearGradient id="wiltedFoliage" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#fbbf24" />
            <stop offset="100%" stopColor="#78350f" />
          </linearGradient>
        </defs>

        {/* Bầu trời */}
        <rect x="0" y="0" width="300" height="240" fill="url(#et-sky)" />

        {/* Sao lấp lánh (khi cây chưa khỏe: trời tối dịu) */}
        {!isHealthy &&
          [
            [20, 18], [60, 40], [95, 14], [130, 30], [205, 20], [235, 48], [275, 22], [180, 10], [40, 70], [262, 78],
          ].map(([x, y], i) => (
            <circle key={i} className="star-twinkle" style={{ animationDelay: `${(i % 5) * 0.5}s` }} cx={x} cy={y} r={i % 3 === 0 ? 1.6 : 1.1} fill="#e0e7ff" />
          ))}

        {/* Mặt trời (cây khỏe) hoặc trăng khuyết (cây cần tưới) */}
        {isHealthy ? (
          <g>
            <circle cx="255" cy="36" r={isLush ? 34 : 26} fill="url(#et-sunGlow)" className="sun-glow" />
            <g className="sun-rays">
              {Array.from({ length: 12 }).map((_, i) => (
                <line key={i} x1="255" y1="14" x2="255" y2="20" stroke="#fde047" strokeWidth="2" strokeLinecap="round" transform={`rotate(${i * 30} 255 36)`} />
              ))}
            </g>
            <circle cx="255" cy="36" r="11" fill="#fde047" />
            <circle cx="252" cy="33" r="4" fill="#fef9c3" opacity="0.8" />
          </g>
        ) : (
          <g>
            <circle cx="255" cy="36" r="20" fill="url(#et-sunGlow)" opacity="0.35" />
            <path d="M 262,24 A 13,13 0 1 0 262,48 A 10,10 0 1 1 262,24 Z" fill="#e0e7ff" />
          </g>
        )}

        {/* Cầu vồng khi cây xum xuê */}
        {isLush && (
          <g className="rainbow-glow" fill="none" strokeWidth="5" opacity="0.35">
            <path d="M 20,190 A 130,130 0 0 1 280,190" stroke="#f87171" />
            <path d="M 26,190 A 124,124 0 0 1 274,190" stroke="#fbbf24" />
            <path d="M 32,190 A 118,118 0 0 1 268,190" stroke="#4ade80" />
            <path d="M 38,190 A 112,112 0 0 1 262,190" stroke="#60a5fa" />
            <path d="M 44,190 A 106,106 0 0 1 256,190" stroke="#a78bfa" />
          </g>
        )}

        {/* Mây trôi */}
        <g className="cloud-drift" fill="#ffffff" opacity={isHealthy ? 0.5 : 0.18}>
          <circle cx="40" cy="38" r="9" /><circle cx="52" cy="33" r="11" /><circle cx="65" cy="38" r="8" /><rect x="40" y="38" width="25" height="8" rx="4" />
        </g>
        <g className="cloud-drift-slow" fill="#ffffff" opacity={isHealthy ? 0.35 : 0.12}>
          <circle cx="160" cy="24" r="6" /><circle cx="169" cy="20" r="8" /><circle cx="178" cy="24" r="6" /><rect x="160" y="24" width="18" height="6" rx="3" />
        </g>

        {/* Chim bay ngang trời khi cây xum xuê */}
        {isLush &&
          [
            { y: 52, d: "0s", s: 1 },
            { y: 64, d: "1.2s", s: 0.8 },
            { y: 45, d: "6s", s: 0.7 },
          ].map((b, i) => (
            <g key={i} transform={`translate(0 ${b.y}) scale(${b.s})`}>
              <g className="bird-fly" style={{ animationDelay: b.d }}>
                <path className="bird-wing" d="M0,0 q4,-4 8,0 q4,-4 8,0" fill="none" stroke="#0f172a" strokeWidth="1.6" strokeLinecap="round" />
              </g>
            </g>
          ))}

        {/* Đồi xa tạo chiều sâu */}
        <path d="M 0,175 Q 60,140 120,168 T 230,160 T 300,170 L 300,240 L 0,240 Z" fill={isHealthy ? "#065f46" : "#1e293b"} opacity="0.7" />
        <path d="M 0,192 Q 80,165 160,188 T 300,182 L 300,240 L 0,240 Z" fill={isHealthy ? "#047857" : "#334155"} opacity="0.75" />

        {/* Hào quang dưới tán cây khi xum xuê */}
        {isLush && <ellipse className="aura-pulse" cx="150" cy="95" rx="110" ry="85" fill="url(#et-aura)" />}

        {/* Đất và thảm cỏ */}
        <ellipse cx="150" cy="215" rx="115" ry="19" fill="url(#soilGrad)" />
        <path d="M 45,215 Q 150,193 255,215 Q 150,231 45,215 Z" fill={isWilted ? "#854d0e" : isHealthy ? "#16a34a" : "#a16207"} />
        <ellipse cx="150" cy="208" rx="80" ry="5" fill="#ffffff" opacity="0.06" />

        {/* Vòng nước loang trên đất khi đang tưới */}
        {isWatering && (
          <g fill="none" stroke="#67e8f9" strokeWidth="1.5">
            <ellipse className="soil-ripple" cx="120" cy="214" rx="14" ry="4" />
            <ellipse className="soil-ripple" style={{ animationDelay: "0.4s" }} cx="180" cy="214" rx="14" ry="4" />
            <ellipse className="soil-ripple" style={{ animationDelay: "0.8s" }} cx="150" cy="218" rx="18" ry="5" />
          </g>
        )}

        {/* Cỏ */}
        {!isWilted && (
          <g stroke="#22c55e" strokeWidth="2" fill="none" strokeLinecap="round">
            {[70, 84, 100, 196, 212, 228, 118, 182].map((x, i) => (
              <path key={i} className="grass-sway" style={{ animationDelay: `${(i % 4) * 0.35}s` }} d={`M ${x},212 Q ${x + 2},202 ${x + 4},212 M ${x + 3},212 Q ${x + 6},199 ${x + 8},212`} />
            ))}
          </g>
        )}

        {/* Hoa nở dưới gốc */}
        {isHealthy &&
          [
            { x: 78, c: "#f472b6" }, { x: 222, c: "#facc15" }, { x: 105, c: "#c084fc" },
            ...(isLush ? [{ x: 195, c: "#fb7185" }, { x: 62, c: "#fde047" }, { x: 240, c: "#f9a8d4" }] : []),
          ].map((f, i) => (
            <g key={i} transform={`translate(${f.x} 212)`}>
              <g className="flower-bob" style={{ animationDelay: `${i * 0.4}s` }}>
                <line x1="0" y1="0" x2="0" y2="-10" stroke="#15803d" strokeWidth="1.5" />
                {[0, 72, 144, 216, 288].map((a) => (
                  <circle key={a} cx={Math.cos((a * Math.PI) / 180) * 3} cy={-12 + Math.sin((a * Math.PI) / 180) * 3} r="2.4" fill={f.c} />
                ))}
                <circle cx="0" cy="-12" r="1.6" fill="#fef3c7" />
              </g>
            </g>
          ))}

        {/* Cả thân và tán cây đung đưa nhẹ theo gió */}
        <g className="tree-sway">
          <g id="treeTrunk">
            <path d="M 135,215 Q 140,160 125,120 Q 120,105 110,90 Q 128,100 142,118 Q 150,130 152,150 Q 155,125 170,95 Q 180,80 190,70 Q 175,85 162,108 Q 158,150 165,215 Z" fill="url(#trunkGrad)" />
            {/* vân gỗ */}
            <path d="M 146,205 Q 148,175 144,150" stroke="#3a1e05" strokeWidth="1.2" fill="none" opacity="0.6" />
            <path d="M 156,200 Q 154,170 158,140" stroke="#a16207" strokeWidth="1" fill="none" opacity="0.45" />
            {/* rễ */}
            <path d="M 135,215 Q 120,222 105,225" stroke="#3a1e05" strokeWidth="4" strokeLinecap="round" fill="none" />
            <path d="M 165,215 Q 180,222 195,225" stroke="#3a1e05" strokeWidth="4" strokeLinecap="round" fill="none" />
            <path d="M 145,217 Q 140,226 132,230" stroke="#3a1e05" strokeWidth="3" strokeLinecap="round" fill="none" />
            <path d="M 156,217 Q 162,226 170,230" stroke="#3a1e05" strokeWidth="3" strokeLinecap="round" fill="none" />
          </g>

          <g id="treeCanopy" className="transition-all duration-700">
            {isLush ? (
              <>
                <circle cx="100" cy="88" r="44" fill="#047857" opacity="0.9" />
                <circle cx="200" cy="88" r="44" fill="#047857" opacity="0.9" />
                <circle cx="150" cy="52" r="52" fill="#065f46" opacity="0.9" />
                <circle cx="110" cy="80" r="38" fill="url(#lushFoliage)" />
                <circle cx="190" cy="80" r="38" fill="url(#lushFoliage)" />
                <circle cx="150" cy="62" r="46" fill="url(#lushFoliage)" />
                <circle cx="150" cy="98" r="36" fill="url(#lushFoliage)" />
                <circle cx="78" cy="102" r="18" fill="url(#lushFoliage)" />
                <circle cx="222" cy="102" r="18" fill="url(#lushFoliage)" />
                {/* ánh sáng trên lá */}
                <ellipse cx="132" cy="40" rx="16" ry="8" fill="#d1fae5" opacity="0.35" />
                <ellipse cx="96" cy="66" rx="10" ry="5" fill="#d1fae5" opacity="0.3" />
                <ellipse cx="186" cy="62" rx="11" ry="5" fill="#d1fae5" opacity="0.3" />
                {/* quả & hoa trên cây */}
                <circle className="fruit-twinkle" cx="120" cy="65" r="5" fill="#f43f5e" />
                <circle className="fruit-twinkle" style={{ animationDelay: "0.6s" }} cx="175" cy="70" r="5" fill="#f43f5e" />
                <circle className="fruit-twinkle" style={{ animationDelay: "1.2s" }} cx="145" cy="45" r="5.5" fill="#fbbf24" />
                <circle className="fruit-twinkle" style={{ animationDelay: "1.8s" }} cx="190" cy="95" r="5" fill="#fbbf24" />
                <circle className="fruit-twinkle" style={{ animationDelay: "0.9s" }} cx="100" cy="100" r="4.5" fill="#fb7185" />
                <circle className="fruit-twinkle" style={{ animationDelay: "1.5s" }} cx="160" cy="110" r="4.5" fill="#f43f5e" />
                <circle cx="135" cy="85" r="2.5" fill="#fbcfe8" /><circle cx="205" cy="80" r="2.5" fill="#fbcfe8" /><circle cx="165" cy="35" r="2.5" fill="#fbcfe8" />
              </>
            ) : isHealthy ? (
              <>
                <circle cx="115" cy="90" r="32" fill="url(#healthyFoliage)" />
                <circle cx="185" cy="90" r="32" fill="url(#healthyFoliage)" />
                <circle cx="150" cy="70" r="40" fill="url(#healthyFoliage)" />
                <circle cx="150" cy="100" r="28" fill="url(#healthyFoliage)" />
                <ellipse cx="136" cy="52" rx="12" ry="6" fill="#dcfce7" opacity="0.35" />
                <ellipse cx="108" cy="78" rx="8" ry="4" fill="#dcfce7" opacity="0.3" />
                <circle cx="130" cy="88" r="2.5" fill="#fef08a" /><circle cx="172" cy="74" r="2.5" fill="#fef08a" />
              </>
            ) : (
              <>
                {/* cành khô lộ ra */}
                <path d="M 120,100 L 100,80 M 180,98 L 202,78 M 150,82 L 150,58" stroke="#5b3a1a" strokeWidth="2.5" strokeLinecap="round" />
                <circle cx="120" cy="95" r="22" fill="url(#wiltedFoliage)" opacity="0.8" />
                <circle cx="180" cy="95" r="22" fill="url(#wiltedFoliage)" opacity="0.8" />
                <circle cx="150" cy="80" r="28" fill="url(#wiltedFoliage)" opacity="0.8" />
              </>
            )}
          </g>
        </g>

        {/* Lấp lánh quanh tán cây khi xum xuê */}
        {isLush &&
          [
            [70, 60], [230, 55], [150, 18], [245, 125], [58, 130],
          ].map(([x, y], i) => (
            <g key={i} transform={`translate(${x} ${y})`}>
              <path className="star-twinkle" style={{ animationDelay: `${i * 0.45}s` }} d={sparkle} fill="#fef9c3" />
            </g>
          ))}

        {/* Cánh hoa bay khi xum xuê */}
        {isLush &&
          [
            { x: 120, y: 70, d: "0s" }, { x: 180, y: 75, d: "1.8s" }, { x: 150, y: 50, d: "3.4s" }, { x: 205, y: 95, d: "5s" },
          ].map((pt, i) => (
            <path key={i} className="petal-fall" style={{ animationDelay: pt.d }} d={`M ${pt.x},${pt.y} q 3,-4 6,0 q -3,4 -6,0 Z`} fill="#f9a8d4" opacity="0" />
          ))}

        {/* Đom đóm bay lên */}
        {(isLush || isHealthy) && (
          <g fill="#fde68a">
            {[
              { x: 70, y: 150, d: "0s" },
              { x: 230, y: 140, d: "1.4s" },
              { x: 95, y: 120, d: "2.6s" },
              { x: 205, y: 175, d: "3.6s" },
              ...(isLush ? [{ x: 150, y: 165, d: "0.8s" }, { x: 255, y: 110, d: "2s" }, { x: 45, y: 100, d: "3s" }] : []),
            ].map((pt, i) => (
              <circle key={i} className="firefly" style={{ animationDelay: pt.d }} cx={pt.x} cy={pt.y} r="2.2" opacity="0" />
            ))}
          </g>
        )}

        {/* Bướm */}
        {isHealthy && (
          <g transform="translate(40 120)">
            <g className="butterfly">
              <path className="butterfly-wing" d="M0,0 C-8,-10 -14,-2 -6,4 Z M0,0 C8,-10 14,-2 6,4 Z" fill="#f9a8d4" />
              <rect x="-0.8" y="-4" width="1.6" height="8" rx="0.8" fill="#831843" />
            </g>
          </g>
        )}
        {isLush && (
          <g transform="translate(230 60)">
            <g className="butterfly butterfly-2">
              <path className="butterfly-wing" d="M0,0 C-7,-9 -12,-2 -5,3 Z M0,0 C7,-9 12,-2 5,3 Z" fill="#fde047" />
              <rect x="-0.7" y="-3.5" width="1.4" height="7" rx="0.7" fill="#713f12" />
            </g>
          </g>
        )}

        {/* Lá úa rơi khi cây rũ lá */}
        {isWilted && (
          <g>
            {[
              { x: 125, y: 95, d: "0s", c: "#f59e0b" },
              { x: 170, y: 90, d: "2.2s", c: "#d97706" },
              { x: 148, y: 75, d: "4s", c: "#b45309" },
              { x: 190, y: 100, d: "1.1s", c: "#f59e0b" },
            ].map((l, i) => (
              <path key={i} className="leaf-fall" style={{ animationDelay: l.d }} d={`M ${l.x},${l.y} q 5,-6 10,0 q -5,6 -10,0 Z`} fill={l.c} opacity="0" />
            ))}
          </g>
        )}

        {/* Khi bấm tưới: bình tưới nghiêng + dòng nước + mưa mát + lấp lánh */}
        {isWatering && (
          <>
            <g transform="translate(38 44)">
              <g className="can-tilt">
                <rect x="0" y="0" width="26" height="18" rx="4" fill="#22d3ee" stroke="#0e7490" strokeWidth="1.5" />
                <path d="M 26,4 L 42,-6 L 44,-3 L 28,10 Z" fill="#22d3ee" stroke="#0e7490" strokeWidth="1.2" />
                <path d="M 2,2 Q -8,9 2,16" fill="none" stroke="#0e7490" strokeWidth="2" />
              </g>
            </g>
            <path className="water-stream" d="M 82,40 Q 105,45 112,70" fill="none" stroke="#a5f3fc" strokeWidth="2.5" strokeLinecap="round" />
            <g stroke="#a5f3fc" strokeWidth="2" strokeLinecap="round">
              {[95, 115, 135, 155, 175, 195, 210, 125, 165, 145].map((x, i) => (
                <line key={i} className="rain-drop" style={{ animationDelay: `${(i % 5) * 0.15}s` }} x1={x} y1={20} x2={x - 2} y2={30} />
              ))}
            </g>
            {[
              [110, 60], [190, 60], [150, 35], [95, 110], [205, 110],
            ].map(([x, y], i) => (
              <g key={i} transform={`translate(${x} ${y})`}>
                <path className="sparkle-pop" style={{ animationDelay: `${i * 0.2}s` }} d={sparkle} fill="#ecfeff" />
              </g>
            ))}
          </>
        )}
      </svg>
    </div>
  );
};

const INITIAL_LOGS: MoodLog[] = [
  {
    id: "log-1",
    date: new Date().toLocaleDateString("vi-VN"),
    time: "08:15:30",
    mood: "Hào Hứng",
    emoji: "🥳",
    stressLevel: 0,
    note: "Khí thế sẵn sàng học tập môn Toán & Tiếng Anh!",
  },
  {
    id: "log-2",
    date: new Date().toLocaleDateString("vi-VN"),
    time: "11:45:10",
    mood: "Bình Thường",
    emoji: "😐",
    stressLevel: 1,
    note: "Hoàn thành bài kiểm tra 15 phút nhẹ nhàng.",
  },
];

interface MoodTrackerViewProps {
  userId?: string;
  grade?: string;
}

type CounselMsg = { role: "user" | "model"; content: string };

// ===== Có thể đổi 2 con số này =====
const MAX_CHECKINS_PER_DAY = 3; // mỗi ngày được check-in cảm xúc tối đa 3 lần
const MAX_LOGS = 30; // Nhật ký chỉ giữ 30 lần gần nhất, cũ hơn tự xóa (lịch 30 ngày vẫn giữ điểm)

type DayStat = { total: number; count: number; taps: number };

// Đổi "28/10/2026" thành ngày để xóa thống kê quá cũ
const parseViDate = (s: string) => {
  const [d, m, y] = s.split("/").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
};

const evaluationOf = (avg: number) =>
  avg > 3.5 ? "Căng thẳng cao - Cần tưới cây & nghỉ ngơi 🌧️" : avg > 2 ? "Áp lực bài vở vừa phải ⛅" : avg > 0.5 ? "Tâm trạng thảnh thơi 🌱" : "Bình an, tinh thần tốt ✨";

export const MoodTrackerView: React.FC<MoodTrackerViewProps> = ({ userId, grade }) => {
  const moodLogsKey = `user_${userId || "default"}_mood_logs`;
  const treeStateKey = `user_${userId || "default"}_emotion_tree_state`;
  const statsKey = `user_${userId || "default"}_mood_daily_stats_v2`;

  const loadSavedLogs = (): MoodLog[] => {
    try {
      const saved = localStorage.getItem(moodLogsKey);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  };

  // Thống kê từng ngày (tổng điểm, số lần) để vẽ lịch 30 ngày, không phụ thuộc nhật ký đã bị xóa bớt
  const [dailyStats, setDailyStats] = useState<Record<string, DayStat>>(() => {
    try {
      const saved = localStorage.getItem(statsKey);
      if (saved) return JSON.parse(saved);
    } catch {}
    const stats: Record<string, DayStat> = {};
    loadSavedLogs().forEach((l) => {
      const st = (stats[l.date] ||= { total: 0, count: 0, taps: 0 });
      st.total += l.stressLevel;
      st.count += 1;
      st.taps += 1;
    });
    return stats;
  });

  const [logs, setLogs] = useState<MoodLog[]>(() => loadSavedLogs().slice(0, MAX_LOGS));

  const [selectedMoodObj, setSelectedMoodObj] = useState(MOOD_OPTIONS[0]);
  const [stressLevel, setStressLevel] = useState<number>(MOOD_OPTIONS[0].score);
  const [note, setNote] = useState("");
  const [isWatering, setIsWatering] = useState(false);

  const [treeState, setTreeState] = useState<EmotionTreeState>(() => {
    const saved = localStorage.getItem(treeStateKey);
    if (saved) {
      try { return JSON.parse(saved); } catch {}
    }
    return {
      health: 85,
      status: "Lush",
      treeLevel: 3,
      lastCheckinDate: new Date().toLocaleDateString("vi-VN"),
      aiExplanation: "Cây cảm xúc đang phát triển xum xuê nhờ các lần check-in vui vẻ và áp lực nhẹ nhàng!"
    };
  });

  const dailySummaries = useMemo(() => {
    const out: { [dateStr: string]: { avgStress: number; moodCount: number; evaluation: string } } = {};
    Object.entries(dailyStats).forEach(([date, st]) => {
      if (st.count > 0) {
        const avg = Number((st.total / st.count).toFixed(1));
        out[date] = { avgStress: avg, moodCount: st.count, evaluation: evaluationOf(avg) };
      }
    });
    return out;
  }, [dailyStats]);

  // AI Counselor Chat: trò chuyện nhiều lượt (không lưu lại để giữ riêng tư cho học sinh)
  const [userStory, setUserStory] = useState("");
  const [isCounseling, setIsCounseling] = useState(false);
  const [counselMsgs, setCounselMsgs] = useState<CounselMsg[]>([]);
  const counselEndRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (counselMsgs.length > 0) counselEndRef.current?.scrollIntoView({ behavior: "smooth", block: "nearest" });
  }, [counselMsgs, isCounseling]);

  // SOS Hug Modal
  const [showSosModal, setShowSosModal] = useState(false);
  const [sosMessage, setSosMessage] = useState("");

  // Breathing state
  const [isBreathing, setIsBreathing] = useState(false);
  const [breathPhase, setBreathPhase] = useState<"Hít vào" | "Giữ hơi" | "Thở ra">("Hít vào");
  const [breathSecondsLeft, setBreathSecondsLeft] = useState(180);

  // AI 30-Day Evaluation
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [aiReport, setAiReport] = useState<{
    psychologicalAssessment?: string;
    carePlan?: string;
  } | null>(null);

  useEffect(() => {
    localStorage.setItem(moodLogsKey, JSON.stringify(logs));
  }, [logs, moodLogsKey]);

  useEffect(() => {
    // Chỉ giữ thống kê 60 ngày gần nhất
    const limit = new Date();
    limit.setDate(limit.getDate() - 60);
    const kept: Record<string, DayStat> = {};
    Object.entries(dailyStats).forEach(([d, st]) => {
      if (parseViDate(d) >= limit) kept[d] = st;
    });
    localStorage.setItem(statsKey, JSON.stringify(kept));
  }, [dailyStats, statsKey]);

  useEffect(() => {
    localStorage.setItem(treeStateKey, JSON.stringify(treeState));
  }, [treeState, treeStateKey]);

  useEffect(() => {
    let timer: any;
    if (isBreathing && breathSecondsLeft > 0) {
      timer = setInterval(() => {
        setBreathSecondsLeft((prev) => prev - 1);
        const cycle = (180 - breathSecondsLeft + 1) % 12;
        if (cycle < 4) setBreathPhase("Hít vào");
        else if (cycle < 8) setBreathPhase("Giữ hơi");
        else setBreathPhase("Thở ra");
      }, 1000);
    } else if (breathSecondsLeft === 0) {
      setIsBreathing(false);
    }
    return () => clearInterval(timer);
  }, [isBreathing, breathSecondsLeft]);

  const handleSelectMood = (m: typeof MOOD_OPTIONS[0]) => {
    setSelectedMoodObj(m);
    setStressLevel(m.score);
  };

  const todayKey = new Date().toLocaleDateString("vi-VN");
  const checkinsToday = dailyStats[todayKey]?.taps || 0;
  const reachedLimit = checkinsToday >= MAX_CHECKINS_PER_DAY;

  const handleAddLogAndWaterTree = () => {
    const now = new Date();
    const todayStr = now.toLocaleDateString("vi-VN");
    if ((dailyStats[todayStr]?.taps || 0) >= MAX_CHECKINS_PER_DAY) return;
    const newEntry: MoodLog = {
      id: "log-" + Date.now(),
      date: todayStr,
      time: now.toLocaleTimeString("vi-VN"),
      mood: selectedMoodObj.label,
      emoji: selectedMoodObj.emoji,
      stressLevel: selectedMoodObj.score,
      note: note.trim() || `Cảm xúc ${selectedMoodObj.label} (Mức áp lực: ${selectedMoodObj.score}/5)`,
    };

    const updatedLogs = [newEntry, ...logs].slice(0, MAX_LOGS);
    setLogs(updatedLogs);
    setDailyStats((prev) => {
      const st = prev[todayStr] || { total: 0, count: 0, taps: 0 };
      return { ...prev, [todayStr]: { total: st.total + newEntry.stressLevel, count: st.count + 1, taps: st.taps + 1 } };
    });
    setNote("");

    setIsWatering(true);
    setTimeout(() => setIsWatering(false), 2500);

    let healthDelta = 0;
    if (selectedMoodObj.score === 0) healthDelta = +15;
    else if (selectedMoodObj.score === 1) healthDelta = +10;
    else if (selectedMoodObj.score === 3) healthDelta = +2;
    else healthDelta = -10;

    const newHealth = Math.min(100, Math.max(10, treeState.health + healthDelta));
    let newStatus: EmotionTreeState["status"] = "Healthy";
    let explanation = "";

    if (newHealth >= 80) {
      newStatus = "Lush";
      explanation = `🎉 Cây cảm xúc đang xum xuê xanh tươi (${newHealth}%)! Tâm trạng "${selectedMoodObj.label}" (Áp lực ${selectedMoodObj.score}/5) đã tưới nguồn năng lượng tích cực cho cây!`;
    } else if (newHealth >= 50) {
      newStatus = "Healthy";
      explanation = `🌱 Cây cảm xúc phát triển khỏe mạnh (${newHealth}%). Em vừa ghi nhận cảm xúc "${selectedMoodObj.label}".`;
    } else {
      newStatus = "SlightlyWilted";
      explanation = `🍂 Cây cảm xúc đang hơi rũ lá (${newHealth}%) vì mức áp lực (${selectedMoodObj.score}/5). Hãy thư giãn 3 phút bài thở để tưới cây mát lại nhé!`;
    }

    setTreeState({
      health: newHealth,
      status: newStatus,
      treeLevel: Math.floor(newHealth / 25) + 1,
      lastCheckinDate: todayStr,
      aiExplanation: explanation
    });
  };

  const recent10Logs = logs.slice(0, 10);
  const avgStress10 = recent10Logs.length > 0
    ? Number((recent10Logs.reduce((acc, curr) => acc + curr.stressLevel, 0) / recent10Logs.length).toFixed(1))
    : 0;

  // Khung báo cáo 30 ngày nằm ngay dưới cây cảm xúc
  const reportRef = useRef<HTMLDivElement>(null);
  const scrollToReport = () => {
    setTimeout(() => reportRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 80);
  };

  // HÀM GỌI API /api/tutor CHUẨN XÁC CHO PHẦN ĐÁNH GIÁ 30 NGÀY
  const handleAnalyze30Days = async () => {
    setIsAnalyzing(true);
    scrollToReport();
    try {
      // Gửi kèm dữ liệu thật của 30 ngày để AI đánh giá sát hơn
      const days30 = getPast30Days();
      const dateSet = new Set(days30.map((d) => d.dateStr));
      const dailyText = days30
        .filter((d) => dailySummaries[d.dateStr])
        .map((d) => `${d.displayDate}: TB ${dailySummaries[d.dateStr].avgStress}/5 (${dailySummaries[d.dateStr].moodCount} lần)`)
        .join("; ");
      const moodCount: Record<string, number> = {};
      logs.filter((l) => dateSet.has(l.date)).forEach((l) => {
        moodCount[l.mood] = (moodCount[l.mood] || 0) + 1;
      });
      const moodText = Object.entries(moodCount).map(([m, c]) => `${m}: ${c} lần`).join(", ");

      const promptText = `Đánh giá sức khỏe tâm lý 30 ngày qua của một học sinh THCS dựa trên nhật ký cảm xúc (thang áp lực 0-5):
- Điểm áp lực trung bình 10 lần check-in gần nhất: ${avgStress10}/5
- Tổng số lần check-in: ${logs.length}
- Điểm trung bình từng ngày: ${dailyText || "chưa có"}
- Số lần mỗi cảm xúc: ${moodText || "chưa có"}

Hãy viết báo cáo ngắn gọn, ấm áp bằng tiếng Việt, xưng "thầy/cô" và gọi học sinh là "em", gồm: **Nhận xét chung**, **Điểm tích cực**, **Điều cần lưu ý**, và **3 lời khuyên cụ thể**. Dùng gạch đầu dòng cho dễ đọc.`;

      const response = await fetch("/api/tutor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subject: "Sức Khỏe Tâm Lý",
          messages: [{ role: "user", content: promptText }]
        }),
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Lỗi kết nối AI");

      setAiReport({
        psychologicalAssessment: data.reply,
        carePlan: "1. Thực hiện bài tập thở sâu 3 phút khi căng thẳng.\n2. Chia sẻ với bạn bè hoặc thầy cô khi gặp áp lực bài vở.\n3. Duy trì check-in cảm xúc mỗi ngày để tưới cây tinh thần."
      });
      scrollToReport();
    } catch (err: any) {
      alert("Không thể phân tích: " + err.message);
    } finally {
      setIsAnalyzing(false);
    }
  };

  // HÀM GỌI API /api/tutor CHUẨN XÁC CHO GÓC AI TÂM SỰ
  const handleAskCounselor = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const text = userStory.trim();
    if (!text || isCounseling) return;

    const history: CounselMsg[] = [...counselMsgs, { role: "user", content: text }];
    setCounselMsgs(history);
    setUserStory("");
    setIsCounseling(true);

    try {
      // Gửi nguyên lời tâm sự; cách trả lời (đồng cảm trước, khuyên sau) được quy định trong api/tutor.js
      const response = await fetch("/api/tutor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subject: "Tâm Sự Học Đường",
          grade,
          messages: history.slice(-10),
        }),
      });

      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || "Lỗi kết nối AI");

      setCounselMsgs([...history, { role: "model", content: data.reply }]);
    } catch (err: any) {
      setCounselMsgs([
        ...history,
        { role: "model", content: "⚠️ Thầy/cô chưa nhận được tin nhắn do lỗi kết nối (" + err.message + "). Em gửi lại giúp thầy/cô nhé!" },
      ]);
    } finally {
      setIsCounseling(false);
    }
  };

  const handleSosHug = () => {
    const hugs = [
      "Em đã làm rất tốt ngày hôm nay rồi! Đừng quá áp lực bản thân nhé. Hãy nghỉ ngơi 10 phút, uống 1 ly nước ấm! ❤️",
      "Mỗi bài kiểm tra chỉ là một bậc thang nhỏ. Dù kết quả thế nào, em vẫn là một học sinh tuyệt vời! ✨",
      "Hít một hơi thật sâu... Thầy cô AI luôn ở đây đồng hành cùng em vượt qua mọi áp lực! 🫂",
    ];
    setSosMessage(hugs[Math.floor(Math.random() * hugs.length)]);
    setShowSosModal(true);
  };

  const handleDeleteLog = (id: string) => {
    const log = logs.find((l) => l.id === id);
    setLogs(logs.filter((l) => l.id !== id));
    if (log) {
      // Xóa nhật ký thì bớt điểm của ngày đó (số lượt check-in trong ngày vẫn giữ nguyên)
      setDailyStats((prev) => {
        const st = prev[log.date];
        if (!st) return prev;
        return { ...prev, [log.date]: { ...st, total: Math.max(0, st.total - log.stressLevel), count: Math.max(0, st.count - 1) } };
      });
    }
  };

  const past30Days = getPast30Days();

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner */}
      <div className="p-6 rounded-3xl bg-gradient-to-r from-rose-900 via-pink-900 to-indigo-950 text-white shadow-xl relative overflow-hidden">
        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-500/30 text-rose-200 text-xs font-bold border border-rose-400/40">
              <Zap className="w-3.5 h-3.5 fill-rose-300 text-rose-300" />
              <span>Theo Dõi Sức Khỏe Tâm Lý & Cây Cảm Xúc THCS ⭐</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              🌳 Cây Cảm Xúc & Bảng Theo Dõi Căng Thẳng
            </h2>
            <p className="text-xs sm:text-sm text-rose-100 leading-relaxed">
              Mỗi lần check-in cảm xúc sẽ tự động tính mức áp lực và tưới Cây Cảm Xúc. Thanh mức độ căng thẳng tự động tính trung bình từ 10 lần đánh giá gần nhất!
            </p>
          </div>

          <button
            onClick={handleSosHug}
            className="px-5 py-3 rounded-2xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-600 hover:to-amber-600 text-white font-extrabold text-xs sm:text-sm shadow-lg shadow-rose-900/50 transition cursor-pointer flex items-center gap-2 shrink-0 animate-pulse"
          >
            <Heart className="w-5 h-5 fill-white" />
            <span>Góc SOS - Cần Lời An Ủi Ngay!</span>
          </button>
        </div>
      </div>

      {/* FEATURE 1: REALISTIC EMOTION TREE CARD */}
      <div className="p-6 rounded-3xl bg-gradient-to-br from-emerald-950 via-teal-950 to-slate-900 text-white border border-emerald-700/50 shadow-xl space-y-4">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="w-full md:w-1/2">
            <RealisticEmotionTree health={treeState.health} isWatering={isWatering} />
          </div>

          <div className="w-full md:w-1/2 space-y-4">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-extrabold border border-emerald-500/30 mb-2">
                Cấp Độ Cây: Level {treeState.treeLevel}
              </div>
              <h3 className="text-2xl font-black text-white">🌳 Cây Cảm Xúc Học Sinh</h3>
              <p className="text-xs text-slate-300 mt-1">
                Trạng thái: <strong className="text-emerald-400">
                  {treeState.health >= 80 ? "Xanh Tươi Xum Xuê ✨" : treeState.health >= 50 ? "Khỏe Mạnh Khá Tốt 🌱" : "Đang Rũ Lá - Cần Tưới Cây 🍂"}
                </strong>
              </p>
            </div>

            <div className="space-y-2 bg-slate-900/90 p-4 rounded-2xl border border-slate-800">
              <div className="flex justify-between text-xs font-bold text-slate-300">
                <span>Sức Khỏe Cây Tinh Thần</span>
                <span className="text-emerald-400">{treeState.health}/100%</span>
              </div>
              <div className="w-full bg-slate-800 h-3.5 rounded-full overflow-hidden p-0.5 border border-slate-700">
                <div
                  className="relative overflow-hidden bg-gradient-to-r from-amber-500 via-emerald-400 to-teal-300 h-full rounded-full transition-all duration-700"
                  style={{ width: `${treeState.health}%` }}
                >
                  <span className="absolute inset-y-0 left-0 w-1/2 bg-gradient-to-r from-transparent via-white/50 to-transparent bar-shimmer" />
                </div>
              </div>
              <p className="text-[11px] text-slate-400 italic">
                Tưới cây tự động mỗi khi bạn bấm chọn cảm xúc vui vẻ & áp lực thấp!
              </p>
            </div>
          </div>
        </div>

        {treeState.aiExplanation && (
          <div className="p-4 rounded-2xl bg-slate-900/90 border border-emerald-500/30 text-xs text-slate-200 leading-relaxed space-y-2">
            <div className="flex items-center gap-2 font-bold text-emerald-400">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>Phân Tích Cây Cảm Xúc:</span>
              <span className="ml-auto text-[10px] font-bold text-amber-300 bg-amber-900/60 px-2 py-0.5 rounded border border-amber-500/30">
                AI chỉ mang tính chất tham khảo
              </span>
            </div>
            <p className="pl-4 border-l-2 border-emerald-400 font-medium text-slate-200">
              {treeState.aiExplanation}
            </p>
          </div>
        )}
      </div>

      {/* BÁO CÁO AI 30 NGÀY: hiện ngay dưới cây cảm xúc */}
      <div ref={reportRef} className="scroll-mt-24">
        {isAnalyzing && !aiReport && (
          <div className="p-6 rounded-3xl bg-gradient-to-br from-indigo-50 via-rose-50 to-amber-50 border border-indigo-200 shadow-sm flex items-center gap-3">
            <Bot className="w-6 h-6 text-indigo-600 animate-spin" />
            <span className="text-sm font-bold text-indigo-900 animate-pulse">
              AI đang đọc nhật ký cảm xúc 30 ngày của em để viết báo cáo...
            </span>
          </div>
        )}

        {aiReport && (
          <div className="p-6 rounded-3xl bg-gradient-to-br from-indigo-50 via-rose-50 to-amber-50 border border-indigo-200 shadow-sm space-y-4 report-pop">
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-50 text-amber-800 border border-amber-200 text-[11px] font-bold">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>AI chỉ mang tính chất tham khảo</span>
                </div>
                <h4 className="font-extrabold text-indigo-950 text-base">
                  🤖 Báo Cáo Đánh Giá AI Sức Khỏe Tâm Lý 30 Ngày
                </h4>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={handleAnalyze30Days}
                  disabled={isAnalyzing}
                  className="px-3 py-1.5 rounded-xl bg-white border border-indigo-200 hover:bg-indigo-50 text-indigo-700 font-bold text-[11px] transition cursor-pointer disabled:opacity-50"
                >
                  {isAnalyzing ? "Đang đánh giá..." : "Đánh giá lại"}
                </button>
                <button
                  onClick={() => setAiReport(null)}
                  title="Ẩn báo cáo"
                  className="p-1.5 rounded-xl bg-white border border-slate-200 hover:bg-slate-100 text-slate-500 transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 text-sm text-slate-800 leading-relaxed">
              {aiReport.psychologicalAssessment && (
                <div className="lg:col-span-2">
                  <span className="font-bold text-indigo-900 block mb-1.5 text-xs">🔍 Đánh giá sức khỏe tâm lý:</span>
                  <div className="bg-white/80 p-4 rounded-2xl border border-indigo-100 text-slate-800">
                    <MathMarkdown>{aiReport.psychologicalAssessment}</MathMarkdown>
                  </div>
                </div>
              )}
              {aiReport.carePlan && (
                <div>
                  <span className="font-bold text-rose-900 block mb-1.5 text-xs">🌱 Kế hoạch chăm sóc tinh thần:</span>
                  <p className="bg-white/80 p-4 rounded-2xl border border-rose-100 text-rose-950 whitespace-pre-line font-medium">
                    {aiReport.carePlan}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* FEATURE 2: STRESS LEVEL CALCULATED FROM LAST 10 CHECK-INS */}
      <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-rose-500" />
              <h3 className="font-extrabold text-slate-900 text-base">
                Thanh Mức Độ Căng Thẳng (Trung Bình 10 Lần Check-in Gần Nhất)
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Tự động tính từ 10 lần đánh giá gần đây nhất (Thang điểm 0 - 5 điểm)
            </p>
          </div>

          <div className="flex items-center gap-2 bg-rose-50 border border-rose-200 px-4 py-2 rounded-2xl self-start sm:self-auto">
            <span className="text-xs font-bold text-rose-900">Điểm Trung Bình:</span>
            <span className="text-xl font-black text-rose-600">{avgStress10} / 5</span>
          </div>
        </div>

        <div className="space-y-2 bg-slate-50 p-4 rounded-2xl border border-slate-200">
          <div className="flex justify-between text-xs font-bold text-slate-700">
            <span>0 điểm (Thư thái)</span>
            <span>2.5 điểm (Vừa)</span>
            <span>5 điểm (Bực tức / Mệt mỏi)</span>
          </div>
          <div className="w-full bg-slate-200 h-4 rounded-full overflow-hidden p-0.5 border border-slate-300">
            <div
              className={`h-full rounded-full transition-all duration-700 ${
                avgStress10 <= 1 ? "bg-emerald-500" : avgStress10 <= 3 ? "bg-amber-500" : "bg-rose-600"
              }`}
              style={{ width: `${(avgStress10 / 5) * 100}%` }}
            ></div>
          </div>
          <p className="text-[11px] text-slate-600 font-medium">
            {avgStress10 <= 1
              ? "✨ Tuyệt vời! Tâm trạng thảnh thơi, áp lực học tập ở mức an toàn."
              : avgStress10 <= 3
              ? "⛅ Áp lực ở mức trung bình. Hãy nghỉ ngơi hợp lý và duy trì thói quen học tập."
              : "🌧️ Áp lực hơi cao! AI khuyên em nên thực hiện bài thở 3 phút hoặc tâm sự ở góc SOS."}
          </p>
        </div>
      </div>

      {/* CHỌN CẢM XÚC & TƯỚI CÂY (đã đổi chỗ lên trên) */}
      <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
            <Smile className="w-5 h-5 text-rose-500" />
            <span>Hôm nay em cảm thấy thế nào?</span>
          </h3>
          <div className={`text-xs font-bold flex items-center gap-1.5 px-3 py-1 rounded-xl self-start ${reachedLimit ? "bg-amber-100 text-amber-800" : "bg-emerald-50 text-emerald-700"}`}>
            <Clock className="w-3.5 h-3.5" />
            <span>Hôm nay: {Math.min(checkinsToday, MAX_CHECKINS_PER_DAY)}/{MAX_CHECKINS_PER_DAY} lần check-in</span>
          </div>
        </div>

        <div className="grid grid-cols-4 lg:grid-cols-8 gap-2.5">
          {MOOD_OPTIONS.map((m) => {
            const isSelected = selectedMoodObj.id === m.id;
            return (
              <button
                key={m.id}
                onClick={() => handleSelectMood(m)}
                disabled={reachedLimit}
                className={`p-2.5 sm:p-3 rounded-2xl border text-center transition cursor-pointer flex flex-col items-center gap-1 relative disabled:cursor-not-allowed disabled:opacity-60 ${
                  isSelected
                    ? "bg-rose-600 text-white border-rose-600 shadow-md shadow-rose-200 scale-105 font-bold"
                    : `${m.bg} font-semibold`
                }`}
              >
                <span className={`text-2xl sm:text-3xl ${isSelected && !reachedLimit ? "animate-bounce" : ""}`}>{m.emoji}</span>
                <span className="text-[11px] sm:text-xs leading-tight">{m.label}</span>
                <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${isSelected ? "bg-white text-rose-700" : "bg-white/80 text-slate-600"}`}>
                  {m.score} điểm
                </span>
              </button>
            );
          })}
        </div>

        {reachedLimit ? (
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-sm font-bold text-amber-800 text-center">
            🌙 Hôm nay em đã check-in đủ {MAX_CHECKINS_PER_DAY} lần rồi. Ngày mai quay lại tưới cây tiếp nhé!
          </div>
        ) : (
          <div className="flex flex-col sm:flex-row gap-3 pt-1">
            <input
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Viết ghi chú ngắn (không bắt buộc). VD: Sáng nay học tốt môn Toán!"
              className="flex-1 px-4 py-3 rounded-2xl border border-slate-200 text-sm bg-slate-50 focus:outline-none focus:ring-2 focus:ring-rose-400 font-medium"
            />
            <button
              onClick={handleAddLogAndWaterTree}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold text-sm transition shadow-md shadow-emerald-200 cursor-pointer flex items-center justify-center gap-2 shrink-0"
            >
              <Droplets className="w-4 h-4 text-cyan-200" />
              <span>Lưu Cảm Xúc & Tưới Cây</span>
            </button>
          </div>
        )}
      </div>

      {/* MAIN CHECK-IN & COUNSELOR GRID */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 space-y-6">
              {/* LỊCH 30 NGÀY (đã đổi chỗ xuống dưới) */}
          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-indigo-600" />
                  <span>Lịch Lưu Kết Quả Trung Bình Ngày (30 Ngày Qua)</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Cuối ngày tự động lưu điểm trung bình ngày & đánh giá tổng kết sau 30 ngày
                </p>
              </div>

              <button
                onClick={handleAnalyze30Days}
                disabled={isAnalyzing}
                className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs transition cursor-pointer flex items-center gap-2 shadow-sm shadow-indigo-200 self-start sm:self-auto"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>{isAnalyzing ? "AI Đang Đánh Giá..." : "🤖 AI Đánh Giá 30 Ngày"}</span>
              </button>
            </div>

            <div className="grid grid-cols-5 sm:grid-cols-10 gap-2 pt-1">
              {past30Days.map((day, idx) => {
                const summary = dailySummaries[day.dateStr];
                const hasData = summary && summary.moodCount > 0;
                const avg = hasData ? summary.avgStress : null;

                let cellBg = "bg-slate-100 border-slate-200 text-slate-400";
                if (hasData && avg !== null) {
                  if (avg > 3.5) cellBg = "bg-rose-500 text-white border-rose-600 font-bold shadow-xs";
                  else if (avg > 1.5) cellBg = "bg-amber-400 text-amber-950 border-amber-500 font-bold shadow-xs";
                  else cellBg = "bg-emerald-500 text-white border-emerald-600 font-bold shadow-xs";
                }

                return (
                  <div
                    key={idx}
                    className={`p-2 rounded-xl border text-center flex flex-col items-center justify-between h-16 transition duration-200 ${cellBg}`}
                    title={hasData ? `${day.dateStr}: TB ${avg}/5 điểm (${summary.evaluation})` : `${day.dateStr}: Chưa check-in`}
                  >
                    <span className="text-[10px] font-bold opacity-80">{day.displayDate}</span>
                    <span className="text-xs font-black my-auto">{hasData ? `${avg}` : "—"}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* AI Counsel Chat (GỌI TRỰC TIẾP /api/tutor) */}
          <div className="p-6 rounded-3xl bg-gradient-to-br from-rose-50 via-pink-50 to-amber-50 border border-rose-200 shadow-sm space-y-4">
            <div className="flex items-center gap-2 text-rose-900 border-b border-rose-200/80 pb-3">
              <div className="p-2 rounded-xl bg-rose-600 text-white">
                <MessageCircle className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h3 className="font-extrabold text-base text-rose-950">🤖 AI Tư Vấn Tâm Lý Học Đường</h3>
                <p className="text-xs text-rose-700 font-semibold mt-0.5">
                  Kể cho thầy/cô nghe chuyện của em nhé, thầy/cô luôn lắng nghe
                </p>
              </div>
              {counselMsgs.length > 0 && (
                <button
                  type="button"
                  onClick={() => !isCounseling && setCounselMsgs([])}
                  className="px-3 py-1.5 rounded-xl bg-white border border-rose-200 hover:bg-rose-50 text-rose-700 font-bold text-[11px] transition cursor-pointer shrink-0"
                >
                  Trò chuyện mới
                </button>
              )}
            </div>

            {/* Khung trò chuyện */}
            {counselMsgs.length > 0 && (
              <div className="space-y-3 max-h-[28rem] overflow-y-auto pr-1">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-amber-50 text-amber-800 border border-amber-200 text-[11px] font-bold">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>AI chỉ mang tính chất tham khảo. Cuộc trò chuyện không được lưu lại.</span>
                </div>
                {counselMsgs.map((m, i) =>
                  m.role === "user" ? (
                    <div key={i} className="flex justify-end">
                      <div className="max-w-[85%] px-4 py-2.5 rounded-2xl rounded-tr-none bg-rose-600 text-white text-sm font-medium whitespace-pre-line shadow-sm">
                        {m.content}
                      </div>
                    </div>
                  ) : (
                    <div key={i} className="flex items-start gap-2">
                      <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                        <Heart className="w-4 h-4 fill-rose-400" />
                      </div>
                      <div className="max-w-[88%] p-3.5 rounded-2xl rounded-tl-none bg-white border border-rose-200 text-slate-700 text-sm leading-relaxed shadow-sm">
                        <MathMarkdown>{m.content}</MathMarkdown>
                      </div>
                    </div>
                  )
                )}
                {isCounseling && (
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center">
                      <Heart className="w-4 h-4 fill-rose-400 animate-pulse" />
                    </div>
                    <div className="px-4 py-2.5 rounded-2xl bg-white border border-rose-200 text-xs text-rose-600 font-bold animate-pulse">
                      Thầy/cô đang đọc và suy nghĩ về điều em chia sẻ...
                    </div>
                  </div>
                )}
                <div ref={counselEndRef} />
              </div>
            )}

            <form onSubmit={handleAskCounselor} className="space-y-3">
              <textarea
                value={userStory}
                onChange={(e) => setUserStory(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
                    e.preventDefault();
                    handleAskCounselor();
                  }
                }}
                rows={counselMsgs.length > 0 ? 2 : 3}
                placeholder={
                  counselMsgs.length > 0
                    ? "Em muốn kể thêm hay hỏi gì nữa không?..."
                    : "Kể chuyện hôm nay để cùng chia sẻ nhé... (VD: Áp lực bài vở, lo lắng thi cử, buồn chuyện bạn bè...)"
                }
                className="w-full p-3.5 rounded-2xl border border-rose-200 bg-white text-sm text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500 font-medium resize-none shadow-xs"
              />

              <div className="flex items-center justify-between">
                <span className="text-[11px] text-rose-600 font-bold">Lắng nghe 24/7 • Enter để gửi</span>
                <button
                  type="submit"
                  disabled={isCounseling || !userStory.trim()}
                  className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-bold text-xs transition flex items-center gap-2 cursor-pointer shadow-sm shadow-rose-200"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isCounseling ? "Thầy/cô đang lắng nghe..." : counselMsgs.length > 0 ? "Gửi" : "Gửi Tâm Sự Tới AI"}</span>
                </button>
              </div>
            </form>
          </div>
        </div>

        <div className="lg:col-span-5 space-y-6">
          <div className="p-6 rounded-3xl bg-white border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-indigo-600" />
                <span>Nhật Ký Cảm Xúc Đã Lưu</span>
              </h3>
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-600" title={`Chỉ giữ ${MAX_LOGS} lần gần nhất`}>
                {logs.length}/{MAX_LOGS}
              </span>
            </div>

            {logs.length === 0 ? (
              <p className="text-xs text-slate-500 py-6 text-center">Chưa có nhật ký cảm xúc nào.</p>
            ) : (
              <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                {logs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-start justify-between gap-3 hover:bg-slate-100 transition text-xs"
                  >
                    <div className="flex items-start gap-2.5">
                      <span className="text-2xl p-1 bg-white rounded-xl shadow-xs">{log.emoji}</span>
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-slate-900">{log.mood}</span>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-800">
                            Áp lực {log.stressLevel}/5
                          </span>
                        </div>
                        <p className="text-slate-600 font-medium">{log.note}</p>
                        <div className="text-[10px] text-slate-400 font-bold flex items-center gap-2 pt-0.5">
                          <span>{log.date}</span>
                          <span>{log.time}</span>
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => handleDeleteLog(log.id)}
                      className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="p-6 rounded-3xl bg-slate-950 text-white border border-slate-800 shadow-md space-y-5">
            <div className="flex items-center justify-between">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 text-xs font-bold">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Thư Giãn 3 Phút</span>
              </div>
              <span className="text-xs text-slate-400 font-mono">Bài thở 4-4-4</span>
            </div>

            <div className="flex flex-col items-center justify-center py-2 space-y-3">
              <div
                className={`w-32 h-32 rounded-full border-4 flex flex-col items-center justify-center transition-all duration-1000 shadow-2xl ${
                  breathPhase === "Hít vào"
                    ? "scale-110 border-rose-400 bg-rose-500/30 shadow-rose-500/50"
                    : breathPhase === "Giữ hơi"
                    ? "scale-105 border-amber-400 bg-amber-500/30 shadow-amber-500/50"
                    : "scale-90 border-cyan-400 bg-cyan-500/30 shadow-cyan-500/50"
                }`}
              >
                <span className="text-base font-extrabold text-white uppercase tracking-wider">
                  {isBreathing ? breathPhase : "THƯ GIÃN"}
                </span>
                <span className="text-xs text-slate-300 font-semibold font-mono mt-1">
                  {Math.floor(breathSecondsLeft / 60)}:
                  {(breathSecondsLeft % 60).toString().padStart(2, "0")}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => setIsBreathing(!isBreathing)}
                className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-extrabold text-xs transition flex items-center gap-2 cursor-pointer shadow-md"
              >
                {isBreathing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                <span>{isBreathing ? "Tạm Dừng" : "Bắt Đầu Tập Thở"}</span>
              </button>
              <button
                onClick={() => {
                  setIsBreathing(false);
                  setBreathSecondsLeft(180);
                  setBreathPhase("Hít vào");
                }}
                className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {showSosModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-rose-200 space-y-4 text-center">
            <div className="w-16 h-16 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center mx-auto shadow-inner">
              <Heart className="w-8 h-8 fill-rose-500" />
            </div>
            <h3 className="text-xl font-extrabold text-slate-900">Gửi Tới Em Một Cái Ôm Ấm Áp! 🫂</h3>
            <p className="text-sm text-slate-700 leading-relaxed font-medium bg-rose-50 p-4 rounded-2xl border border-rose-100">
              {sosMessage}
            </p>
            <button
              onClick={() => setShowSosModal(false)}
              className="w-full py-3 rounded-2xl bg-rose-600 text-white font-extrabold text-sm shadow-md shadow-rose-200 cursor-pointer"
            >
              Cảm Ơn AI, Em Đã Thấy Khá Hơn Rồi! ❤️
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
